package Encapsulation;

public class encapsulation {
	
	private String name;
	String getName() {
	return name;
	}

	void setName(String name) {
	this.name=name;

	}



	 }

