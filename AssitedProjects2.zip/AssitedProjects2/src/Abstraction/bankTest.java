package Abstraction;

public class bankTest {

public static void main(String[] args) {
Bank obj = new SBI();
Bank obj1 = new pnb();
obj.RateOfInterest();
obj1.RateOfInterest();
}
}

