package Inheritance;

public class inheritance1 extends inheritance {
int sum;

void sum() {
this.sum = this.x + this.y;
System.out.println("sum is :"+sum);
}

}