package DiamondProblem;

interface interface1 {

public default void display() {
System.out.println("inside display method of interface1.........");

}

}
